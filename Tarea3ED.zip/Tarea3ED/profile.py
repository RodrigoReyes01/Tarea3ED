import cProfile
import function3 as fun

cProfile.run("fun.valx(2)")
cProfile.run("fun.valy(-1)")
cProfile.run("fun.findCua(2,-1)")
